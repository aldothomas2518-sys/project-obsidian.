PROJECT OBSIDIAN V4 — ANDROID APK BUILDER

This project packages the included Project Obsidian V4 browser prototype inside a basic Android WebView app.
It is a prototype APK wrapper, not the complete production Flutter/Supabase application.

BUILD ON A PHONE WITH GITHUB ACTIONS
1. Create a GitHub repository.
2. Extract this ZIP and upload ALL extracted files/folders to the repository root, preserving folder structure.
3. Open the repository's Actions tab. Allow GitHub Actions if prompted.
4. Select "Build Project Obsidian Android APK" and tap Run workflow (or push a commit to trigger it).
5. Open the completed workflow run. Under Artifacts, download the APK artifact.
6. Extract the downloaded artifact ZIP if GitHub downloads it as a ZIP, then tap the APK to install. Android may ask you to allow installs from that source.

NOTES
- Java and Kotlin are configured for JVM 17.
- The app loads app/src/main/assets/index.html, which is the V4 prototype.
- Browser localStorage and the APK's WebView storage are separate. This build does not include cloud sync.
- This is not yet the full blueprint app; features such as Supabase sync and the complete Flutter implementation are not included.
