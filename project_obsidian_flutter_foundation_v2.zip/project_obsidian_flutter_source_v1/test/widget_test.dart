import 'package:flutter_test/flutter_test.dart';
import 'package:project_obsidian/app/obsidian_app.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  testWidgets('shows the six-section Obsidian shell', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: ObsidianApp()));
    expect(find.text('PROJECT OBSIDIAN'), findsWidgets);
    expect(find.text('Command'), findsOneWidget);
  });
}
