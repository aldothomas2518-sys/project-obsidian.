# PROJECT OBSIDIAN — Flutter Foundation V2

This is the first native Flutter foundation for Project Obsidian. It replaces the HTML/WebView wrapper as the intended application codebase. It is **not** the finished Master Blueprint application yet.

## Included
- Flutter app entry point and dark Obsidian theme
- Adaptive navigation shell for phone and wide layouts
- Six blueprint sections: Command Center, Character, Missions, Progression, Legacy, System
- Initial feature-page scaffolds and mission interaction prototype
- Supabase initialization through compile-time environment values (not configured by default)
- Local database foundation files and initial Supabase migration
- GitHub Actions workflow using Flutter's Android build environment (does not call `android-actions/setup-android`)

## Build on GitHub
1. Put the contents of this folder at the root of your GitHub repository (not inside an extra nested folder).
2. Commit and push to `main`.
3. Open **Actions** and run **Project Obsidian Flutter Android**.
4. Wait for Analyze, Tests, and Build to finish.
5. Download the `project-obsidian-flutter-apk` artifact. It contains a debug APK for testing.

## Local build
Install Flutter stable, then run:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

## Supabase
The app only initializes Supabase when both `SUPABASE_URL` and `SUPABASE_ANON_KEY` are supplied at build time. Do not commit service-role keys. Configure Row Level Security before connecting real user data.

## Important status
- The existing pages are early native Flutter scaffolds, not complete feature implementations.
- The Drift database and SQL migration are foundation artifacts and are not yet fully integrated with all screens.
- Cloud synchronization, Google authentication, full XP ledger, historical audit UI, complete RPG inventory, cinematic assets/audio, Ballon d'Or scoring, backup/restore, and production security remain to be implemented and tested.
- No APK is included in this source ZIP. GitHub Actions builds it.
