import 'package:flutter/material.dart';
import '../core/theme/obsidian_theme.dart';
import '../features/shell/presentation/obsidian_shell.dart';
class ObsidianApp extends StatelessWidget {
  const ObsidianApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'PROJECT OBSIDIAN', debugShowCheckedModeBanner: false,
    theme: ObsidianTheme.dark, home: const ObsidianShell());
}
