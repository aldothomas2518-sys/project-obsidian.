import 'package:flutter/material.dart';
import '../../command_center/presentation/page.dart';
import '../../character/presentation/page.dart';
import '../../missions/presentation/page.dart';
import '../../progression/presentation/page.dart';
import '../../legacy/presentation/page.dart';
import '../../system/presentation/page.dart';
class ObsidianShell extends StatefulWidget { const ObsidianShell({super.key}); @override State<ObsidianShell> createState()=>_State(); }
class _State extends State<ObsidianShell> {
 int index=0;
 final pages=const [CommandPage(),CharacterPage(),MissionsPage(),ProgressionPage(),LegacyPage(),SystemPage()];
 final labels=const ['Command','Character','Missions','Progress','Legacy','System'];
 final icons=const [Icons.dashboard,Icons.person,Icons.flag,Icons.trending_up,Icons.emoji_events,Icons.settings];
 @override Widget build(BuildContext context)=>LayoutBuilder(builder:(context,c){
  final wide=c.maxWidth>=760;
  return Scaffold(body:Row(children:[if(wide) NavigationRail(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),labelType:NavigationRailLabelType.all,destinations:List.generate(6,(i)=>NavigationRailDestination(icon:Icon(icons[i]),label:Text(labels[i])))),Expanded(child:IndexedStack(index:index,children:pages))]),
   bottomNavigationBar:wide?null:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:List.generate(6,(i)=>NavigationDestination(icon:Icon(icons[i]),label:labels[i]))));
 });
}
