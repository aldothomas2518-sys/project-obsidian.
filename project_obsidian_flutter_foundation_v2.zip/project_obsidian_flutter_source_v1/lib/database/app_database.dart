// Drift local database foundation. Generate with build_runner.
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'dart:io';
part 'app_database.g.dart';
class LocalProfile extends Table {TextColumn get id=>text()();TextColumn get displayName=>text()();TextColumn get playerClass=>text().withDefault(const Constant('Student Warrior'))();IntColumn get createdAtUtcMs=>integer()();IntColumn get updatedAtUtcMs=>integer()();@override Set<Column> get primaryKey=>{id};}
@DriftDatabase(tables:[LocalProfile]) class AppDatabase extends _$AppDatabase {AppDatabase():super(_connect());@override int get schemaVersion=>1;}
LazyDatabase _connect()=>LazyDatabase(()async{final d=await getApplicationDocumentsDirectory();return NativeDatabase.createInBackground(File(p.join(d.path,'obsidian.sqlite')));});
