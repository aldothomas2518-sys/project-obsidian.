import 'package:flutter/material.dart';
class ObsidianTheme {
  static const cyan = Color(0xFF38D9F5);
  static ThemeData get dark => ThemeData(
    brightness: Brightness.dark, useMaterial3: true,
    scaffoldBackgroundColor: const Color(0xFF080B12),
    colorScheme: const ColorScheme.dark(primary: cyan, secondary: Color(0xFF6A8DFF), surface: Color(0xFF111824)),
    cardTheme: CardThemeData(color: const Color(0xFF111824), elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF080B12), elevation: 0),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF182333),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)));
}
