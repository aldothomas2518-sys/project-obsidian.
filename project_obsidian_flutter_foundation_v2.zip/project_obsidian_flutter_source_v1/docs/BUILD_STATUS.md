# Build status and next engineering gates

## V2 foundation scope
This package establishes the native Flutter codebase and a repeatable Android build pipeline. It is a foundation milestone, not a feature-complete release.

## Required next work
1. Integrate Drift tables and migrations into the running app; add repositories and tests.
2. Move mission/profile state into persistent repositories; implement the confirmed daily XP ledger and exactly-once confirmation.
3. Implement audit-history-aware corrections and conflict-safe sync queue.
4. Implement Supabase schema/RLS and Google sign-in, then offline-first sync.
5. Complete each of the six blueprint sections and test Android/Windows layouts.
6. Add cinematic assets, accessibility/performance controls, export/import, and release signing.

## Historical data safety
The conflicting historical XP/level snapshots in the approved blueprint must remain separate until an explicit audit. Do not seed a guessed level, rank, or XP total into the app.
